/* eslint-disable  func-names */
/* eslint quote-props: ["error", "consistent"]*/

'use strict';

const Alexa = require('alexa-sdk');

const APP_ID = undefined;  // TODO replace with your app ID (OPTIONAL).

const FACTS = [
  {
    'name': 'Spiderman',
    'fact': 'He became super-human after he was bit by a spider.',
    'level': 1
  },
  {
    'name': 'Spiderman',
    'fact': 'His name is Peter Parker.',
    'level': 2
  },
  {
    'name': 'Superman',
    'fact': 'He can fly.',
    'level': 1
  },
  {
    'name': 'Superman',
    'fact': 'He wears red and blue clothes.',
    'level': 1
  },
  {
    'name': 'Superman',
    'fact': 'He can fire laser with his eyes.',
    'level': 2
  },
  {
    'name': 'Superman',
    'fact': 'He wears his underwear over his pants.',
    'level': 3
  }
];

const about = 'Guess the Superhero is a Alexa skill by Zoya Aslam, \
which tells some facts about any Superhero or Supervillain and asks you to correctly guess him or her.';
const help = about;
const goodbye = 'Thanks for playing Guess the Superhero. Goodbye!';

let isMatchingNames = function(a, b) {
  return a.toUpperCase() === b.toUpperCase();
}

let allFacts = function (level, name) {
  if (!level && !name) {
    return FACTS;
  }

  let facts = FACTS.filter(function(fact) {
    let levelMatch = level ? level === fact.level : true;
    let nameMatch = name ? isMatchingNames(name, fact.name) : true;
    
    return levelMatch && nameMatch; 
  });
  
  return facts;
};

let maxLevel = function(level, name) {
  let max = 1;
  FACTS.forEach(function(fact) {
    if (fact.level > max) {
      max = fact.level;
    }  
  });
  
  return max;
};

let getRandomFact = function(facts) {
  let idx = Math.floor(Math.random() * facts.length);
  let _facts = facts.splice(idx, 1);
  return _facts[0];
};

let checkAnswer = function(fact, answer) {
  return isMatchingNames(fact.name, answer);
}

const handlers = {
  'LaunchRequest': function () {
    this.attributes['level'] = 1;
    this.attributes['facts'] = allFacts(this.attributes['level']);
    this.attributes['score'] = 0;

    this.emit(':ask', about);
  },
  'NextFactIntent': function () {
    this.attributes['question'] = getRandomFact(this.attributes['facts']);
    if (!this.attributes['question']) {
      this.attributes['level'] = ++ this.attributes['level'];
    }
    this.emit(':ask', this.attributes['question'].fact + '. Who do you think he/she is?');
  },
  'AnswerIntent': function () {
    const answer = this.event.request.intent.slots.Answer.value;
    if (checkAnswer(this.attributes['question'], answer)) {
      this.attributes['score'] = ++ this.attributes['score'];
      this.emit(':tell', answer + ' is correct answer.');
    } else {
      this.emit(':tell', answer + ' is incorrect answer.');
    }
  },
  'CheckLevelIntent': function () {
    this.emit(':tell', 'You at ' + this.attributes['level'] + ' in this game');
  },
  'CheckScoreIntent': function () {
    this.emit(':tell', 'Your score in this game is ' + this.attributes['score']);
  },  
  'AMAZON.HelpIntent': function () {
    this.emit(':ask', help);
  },
  'AMAZON.CancelIntent': function () {
    this.emit(':tell', goodbye);
  },
  'AMAZON.StopIntent': function () {
    this.emit(':tell', goodbye);
  },
  "Unhandled": function() {
    this.emit(':ask', 'Can\'t decode, starting again.');
  }
};

exports.handler = function (event, context) {
  const alexa = Alexa.handler(event, context);
  alexa.APP_ID = APP_ID;
  alexa.registerHandlers(handlers);
  alexa.execute();
};
